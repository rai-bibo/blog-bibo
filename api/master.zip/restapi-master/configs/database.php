<?php

//database configurations
define('DATABASE_HOST', 'localhost');
define('DATABASE_USER', 'root');
define('DATABASE_PASSWORD', '');
define('DATABASE_NAME', 'restapi');
define('DATABASE_PORT', 3306);
define('DATABASE_DEFAULT_LIMIT', 20);
define('DATABASE_MAX', 50);